import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';


class RedButton extends Component {
  displayAlert= ()=>{
    alert("THIS IS AN ALRET!!!!!");
  }
  render(){
    return(
      <Button title="CLICK ME!" color= "red" onPress={this.displayAlert}/>
    );
  }
}

export default class App extends Component {
  render() {
    return (
      <View style={{marginTop: 200}}>
        <RedButton/>
        <Text>My First React Component</Text>
      </View>
    );
  }
}